select *
from users
where auth_id = $1; 