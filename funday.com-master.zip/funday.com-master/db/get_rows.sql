select *
from rows;