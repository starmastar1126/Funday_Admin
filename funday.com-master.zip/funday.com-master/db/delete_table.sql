delete from tables
where table_id = $1;

select *
from tables;