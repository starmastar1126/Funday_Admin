select *
from tables;