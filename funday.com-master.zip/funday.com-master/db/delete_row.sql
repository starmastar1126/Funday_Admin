delete from rows
where row_id = $1;

select *
from rows;