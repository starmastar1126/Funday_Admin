select *
from boards;