select *
from users;