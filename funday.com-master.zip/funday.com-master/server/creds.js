const { CREDS_EMAIL, CREDS_PASS } = process.env;
module.exports = {
  USER: CREDS_EMAIL,
  PASS: CREDS_PASS
};
